# -*- coding:utf-8 -*-
import sys
sys.path.append('/mnt/mmcblk0p1/pysdk/lib')
from URMessageChannel import TimerEvtHandle, logconfig, init_base
import subprocess
import re
import socket
import time

class startWork(TimerEvtHandle):
    def __init__(self, sec):
        self.base = init_base()
        TimerEvtHandle.__init__(self, self.base, sec)
        self.UDP_IP = "224.0.0.10"
        self.UDP_PORT = 8500
        self.gps_types = ["$GPGGA","$GPRMC","$GPGSV","$GPGSA"]
        self.buffer = {}
        self.local_ip = self.get_bridge0_ip()

    def get_bridge0_ip(self):
        try:
            output = subprocess.check_output("ifconfig Bridge0", shell=True).decode()
            match = re.search(r'inet addr:(\d+\.\d+\.\d+\.\d+)', output)
            if match:
                return match.group(1)
        except Exception:
            pass
        return "127.0.0.1"

    def timerHandle(self, evt, userdata):
        self.collect_and_send()
        self.startTimer()

    def collect_and_send(self):
        try:
            output = subprocess.check_output(
                'vtysh_ubus -c "enable" -c "show gps data"', shell=True
            ).decode('utf-8', errors='ignore')
        except Exception:
            return

        for line in output.splitlines():
            line = line.strip()
            for t in self.gps_types:
                if line.startswith(t):
                    self.buffer[t] = line
            if len(self.buffer) == len(self.gps_types):
                data = '\n'.join([self.buffer[t] for t in self.gps_types]).encode('utf-8')
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(self.local_ip))
                sock.sendto(data, (self.UDP_IP, self.UDP_PORT))
                sock.close()
                self.buffer.clear()
                break

def start_app():
    pass

def usage():
    print('add help info')
    sys.exit(255)

def main(argv=sys.argv):
    import getopt
    short_args="h:"
    long_args=["help",]
    arguments = argv[1:]
    try:
        opts, args = getopt.getopt(arguments, short_args, long_args)
    except:
        usage()
    for option, value in opts:
        if option in ('-h', '--help'):
            usage()
    logconfig('info')
    work = startWork(1)
    work.start()

if __name__=='__main__':
    main()
