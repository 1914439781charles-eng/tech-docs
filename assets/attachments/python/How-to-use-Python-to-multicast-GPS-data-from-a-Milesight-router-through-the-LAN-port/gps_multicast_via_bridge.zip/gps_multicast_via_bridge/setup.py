from setuptools import setup, find_packages
setup(
    name='hello',   #app name
    sdk_version='1.0.3',    #which sdk version that app runing
    version='0.0.1',    #app version
    author='ursalink',   
    author_email='ursalink@example.com',
    description='hello test',
    license='PRIVATE',  #app license, you can use GPL, MIT, BSD...
    packages = find_packages('src'),
    package_dir={ '' : 'src' },
    zip_safe=False,
    install_requires=[
    ],
    #your app entrty points, you just implement it like "appnamne = Application:main" 
    entry_points = """
		[console_scripts]
		hello = Application:main
		"""
)