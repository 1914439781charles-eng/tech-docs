# -*- coding:utf-8 -*-
import sys
import os
from URMessageChannel import TimerEvtHandle, logconfig, init_base
import subprocess
import requests
import json
import URInterface
import URRouterInfo
class startWork(TimerEvtHandle):
    def __init__(self, sec):
        self.base = init_base()
        TimerEvtHandle.__init__(self, self.base, sec)
        self.dil = URInterface.DIn(1)


    def timerHandle(self, evt, userdata):


        self.dis = self.dil.getCurConfig()
        try:
                self.config = json.loads(self.dis)
        except Exception as e:
                print("error")
                self.config={}
        self.io_status = self.config.get('io_status')

        if self.io_status is None:
            self.io_status = 2
        self.http_send(self.io_status)
        self.startTimer()

    def http_send(self, sta):
        try:
                num = sta
                url = "http://192.168.45.245"
                response = requests.post(url, json={'number': num})
        except Exception as e:
                print("HTTP")
                return




def start_app():
    pass

def usage():
    print('add help info')
    sys.exit(255)

def main(argv=sys.argv):
    import getopt
    short_args="h:"
    long_args=["help",]
    arguments = argv[1:]
    try:
        opts, args = getopt.getopt(arguments, short_args, long_args)
    except:
        usage()
    for option, value in opts:
        if option in ('-h', '--help'):
            usage()
    logconfig('info')
    work = startWork(5)
    work.start()

if __name__=='__main__':
    main()
    
